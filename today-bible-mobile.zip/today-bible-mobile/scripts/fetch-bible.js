const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');
const version = process.argv[2] || 'ko_ko';
const url = `https://raw.githubusercontent.com/thiagobodruk/bible/master/json/${version}.json`;
https.get(url, res => {
  if (res.statusCode !== 200) { console.error(`본문 다운로드 실패: HTTP ${res.statusCode}\n주소: ${url}`); process.exit(1); }
  let body = '';
  res.setEncoding('utf8');
  res.on('data', chunk => body += chunk);
  res.on('end', () => {
    try {
      const source = JSON.parse(body);
      const books = source.map(book => {
        if (Array.isArray(book.chapters) && Array.isArray(book.chapters[0])) return book.chapters;
        throw new Error(`지원하지 않는 JSON 구조: ${book.name || book.book || 'unknown'}`);
      });
      if (books.length !== 66) throw new Error(`성경 책 수가 66권이 아닙니다: ${books.length}권`);
      const out = path.join(__dirname, '..', 'assets', 'bible.json');
      fs.mkdirSync(path.dirname(out), {recursive:true});
      fs.writeFileSync(out, JSON.stringify(books), 'utf8');
      console.log(`완료: ${out} (${books.length}권)`);
    } catch (e) { console.error('본문 변환 실패:', e.message); process.exit(1); }
  });
}).on('error', e => { console.error('다운로드 오류:', e.message); process.exit(1); });
