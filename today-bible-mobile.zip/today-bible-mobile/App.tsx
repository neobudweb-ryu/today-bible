import React, {useMemo, useState} from 'react';
import {SafeAreaView, ScrollView, View, Text, TextInput, Pressable, StyleSheet, Alert} from 'react-native';
import {BOOK_KO, bible, verseText, searchVerses, refLabel} from './src/data/bible';
import {scheduleDaily, TIME_PRESETS} from './src/notify';

export default function App() {
  const [book, setBook] = useState(0);
  const [chapter, setChapter] = useState(1);
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState<'read'|'search'>('read');
  const [alerts, setAlerts] = useState<string[]>(['07:00']);
  const chapterCount = bible[book]?.length || 1;
  const verses = bible[book]?.[chapter-1] || [];
  const hits = useMemo(() => query.trim() ? searchVerses(query, 100) : [], [query]);
  const moveBook = (n:number) => { const next=Math.max(0,Math.min(65,n)); setBook(next); setChapter(1); };
  const toggleAlert = (time:string) => setAlerts(old => old.includes(time) ? old.filter(x=>x!==time) : old.length<3 ? [...old,time] : old);
  const saveAlerts = async () => { try { const ok=await scheduleDaily(alerts); Alert.alert(ok?'알림 설정 완료':'알림 권한 필요', ok?'선택한 시간에 매일 말씀 알림을 보냅니다.':'휴대폰 설정에서 알림 권한을 허용해 주세요.'); } catch { Alert.alert('오류','알림 설정 중 문제가 발생했습니다.'); } };
  return <SafeAreaView style={s.safe}><View style={s.header}><Text style={s.brand}>오늘 성경</Text><Text style={s.sub}>말씀을 읽고 묵상하는 시간</Text></View>
    <View style={s.tabs}><Pressable style={[s.tab,tab==='read'&&s.active]} onPress={()=>setTab('read')}><Text>성경 읽기</Text></Pressable><Pressable style={[s.tab,tab==='search'&&s.active]} onPress={()=>setTab('search')}><Text>구절 검색</Text></Pressable></View>
    {tab==='read' ? <><View style={s.picker}><Pressable style={s.smallBtn} onPress={()=>moveBook(book-1)}><Text>이전 책</Text></Pressable><Text style={s.book}>{BOOK_KO[book]}</Text><Pressable style={s.smallBtn} onPress={()=>moveBook(book+1)}><Text>다음 책</Text></Pressable></View>
      <View style={s.picker}><Pressable style={s.smallBtn} onPress={()=>setChapter(Math.max(1,chapter-1))}><Text>이전 장</Text></Pressable><Text style={s.book}>{chapter}장 / {chapterCount}장</Text><Pressable style={s.smallBtn} onPress={()=>setChapter(Math.min(chapterCount,chapter+1))}><Text>다음 장</Text></Pressable></View>
      <ScrollView contentContainerStyle={s.content}><Text style={s.heading}>{BOOK_KO[book]} {chapter}장</Text>{verses.map((v,i)=><Text key={i} style={s.verse}><Text style={s.num}>{i+1} </Text>{v}</Text>)}</ScrollView></>
    : <><TextInput style={s.input} value={query} onChangeText={setQuery} placeholder="검색할 단어를 입력하세요"/><ScrollView contentContainerStyle={s.content}>{hits.map((h,i)=><View key={i} style={s.hit}><Text style={s.hitRef}>{refLabel(h.b,h.c,h.v)}</Text><Text>{h.t}</Text></View>)}{query.trim()!==''&&hits.length===0&&<Text>검색 결과가 없습니다.</Text>}</ScrollView></>}
    <View style={s.alertBox}><Text style={s.alertTitle}>매일 말씀 알림 (최대 3개)</Text><View style={s.times}>{TIME_PRESETS.map(t=><Pressable key={t} onPress={()=>toggleAlert(t)} style={[s.time,alerts.includes(t)&&s.timeOn]}><Text style={alerts.includes(t)?s.timeTextOn:s.timeText}>{t}</Text></Pressable>)}</View><Pressable style={s.save} onPress={saveAlerts}><Text style={s.saveText}>알림 시간 저장</Text></Pressable></View>
  </SafeAreaView>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#f7f5ef'},header:{padding:18,backgroundColor:'#314b3b'},brand:{fontSize:25,fontWeight:'800',color:'#fff'},sub:{color:'#e5eadf',marginTop:4},tabs:{flexDirection:'row',padding:10,gap:8},tab:{flex:1,padding:12,alignItems:'center',backgroundColor:'#e8e5dc',borderRadius:10},active:{backgroundColor:'#d2dfd1'},picker:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:14,paddingVertical:7},book:{fontSize:18,fontWeight:'700',color:'#26382c'},smallBtn:{padding:9,backgroundColor:'#e8e5dc',borderRadius:8},content:{padding:18,paddingBottom:30},heading:{fontSize:22,fontWeight:'700',marginBottom:14,color:'#314b3b'},verse:{fontSize:17,lineHeight:29,color:'#292929',marginBottom:7},num:{fontWeight:'700',color:'#71836f'},input:{margin:14,padding:13,backgroundColor:'#fff',borderRadius:10,fontSize:16},hit:{backgroundColor:'#fff',padding:13,borderRadius:9,marginBottom:9},hitRef:{fontWeight:'700',color:'#314b3b',marginBottom:5},alertBox:{padding:12,backgroundColor:'#ece9df'},alertTitle:{fontWeight:'700',marginBottom:8},times:{flexDirection:'row',flexWrap:'wrap',gap:7},time:{paddingVertical:8,paddingHorizontal:13,borderRadius:8,backgroundColor:'#fff'},timeOn:{backgroundColor:'#314b3b'},timeText:{color:'#333'},timeTextOn:{color:'#fff',fontWeight:'700'},save:{marginTop:9,backgroundColor:'#314b3b',padding:11,borderRadius:9,alignItems:'center'},saveText:{color:'#fff',fontWeight:'700'}});
