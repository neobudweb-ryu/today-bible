# 오늘 성경 모바일 실행 프로젝트

## 실행 환경
- PC 또는 Mac에 Node.js LTS 설치
- Android 휴대폰에 Expo Go 설치

## 설치 및 실행
```bash
npm install
node scripts/fetch-bible.js
npx expo start
```
터미널에 표시되는 QR 코드를 Android의 Expo Go로 스캔합니다. PC와 휴대폰은 같은 Wi-Fi에 연결하세요. 연결이 안 되면 `npx expo start --tunnel`을 사용하세요.

## APK 만들기
Expo Go 테스트가 끝난 뒤 EAS Build로 APK를 만들 수 있습니다.
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
```
`eas.json`에서 preview 프로필의 `android.buildType`을 `apk`로 설정한 후 빌드하세요.

## 중요
- 현재 제공된 업로드에는 원래 README와 `src/data/bible.ts`, `src/notify.ts`만 있었습니다. 실제 화면 파일과 본문 다운로드 스크립트가 없어, 이 패키지에는 모바일에서 구동할 기본 읽기/검색/알림 화면과 다운로드 스크립트를 새로 구성했습니다.
- 기존 README에 적힌 개역한글/개역개정 본문이라고 보장할 수 없습니다. 기본 스크립트는 원본 저장소의 `ko_ko` 데이터를 받습니다. 본문 버전과 앱 배포 권리는 별도로 확인해야 합니다.
- 북마크, 하이라이트, 묵상 메모, 365일 읽기 계획 화면은 원본 업로드에 구현 파일이 없어 아직 포함되지 않았습니다.
